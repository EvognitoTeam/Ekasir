'use client';

import {
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

type HttpMethod =
  | 'GET'
  | 'POST'
  | 'PATCH'
  | 'PUT'
  | 'DELETE';

type ApiError = {
  code?: string;
  message?: string;
  details?: unknown;
};

type ApiResponse<T = unknown> = {
  success?: boolean;
  message?: string;
  data?: T;
  meta?: unknown;
  error?: ApiError;
};

type RequestLog = {
  id: string;
  startedAt: string;
  finishedAt: string;
  durationMs: number;

  method: HttpMethod;
  url: string;

  requestHeaders: Record<string, string>;
  requestBody: unknown;

  status: number | null;
  statusText: string | null;
  contentType: string | null;

  responseHeaders: Record<string, string>;
  responseBody: unknown;

  ok: boolean;

  errorName: string | null;
  errorMessage: string | null;
  errorStack: string | null;
};

type Product = {
  id: number;
  name: string;
  price?: number | string;
};

type PosTable = {
  id: number;
  code?: string;
  table_code?: string;
  name?: string;
  table_name?: string;
};

type MemberData = {
  id?: number;
  userId?: number;

  memberId?: string;
  member_id?: string;

  name?: string;
  email?: string;
  phone?: string;
  phoneNumber?: string;

  points?: number;
  tier?: string;
};

type QrisData = {
  orderId?: number;
  orderCode?: string;

  orderStatus?: string;

  paymentMethod?: string;
  paymentStatus?: string;
  paymentStatusLabel?: string;

  transactionId?: string | null;
  transactionStatus?: string | null;

  paymentType?: string | null;
  issuer?: string | null;

  qrUrl?: string | null;
  qr_url?: string | null;

  qrString?: string | null;
  qr_string?: string | null;

  expiryTime?: string | null;
  expiry_time?: string | null;

  paidAt?: string | null;
  paymentPaidAt?: string | null;

  isExpired?: boolean;

  total?: number | string;
  tax?: number | string;
  service?: number | string;
};

type PointsConfigData = {
  enabled?: boolean;

  earning?: {
    rupiahPerPoint?: number;
    example?: {
      transactionAmount?: number;
      pointsEarned?: number;
    };
  };

  redemption?: {
    rupiahPerPoint?: number;
    minimumPoints?: number;
    maximumPoints?: number | null;
    maxDiscountPercent?: number;

    example?: {
      points?: number;
      discountValue?: number;
    };
  };

  rules?: {
    requirePaidOrder?: boolean;
    includeTaxService?: boolean;
  };

  source?: {
    settingsId?: number | null;
    mitraId?: number;
    usingDefault?: boolean;
    updatedAt?: string | null;
  };
};

type OrderCreateData = QrisData & {
  orderId?: number;
  orderCode?: string;

  grandTotal?: number;
  total?: number;

  pointsEstimate?: number;
};

const STORAGE_KEY =
  'ekasir_mobile_api_tester_latest';

function generateUuid(): string {
  if (
    typeof crypto !== 'undefined' &&
    typeof crypto.randomUUID === 'function'
  ) {
    return crypto.randomUUID();
  }

  return `${Date.now()}-${Math.random()
    .toString(16)
    .slice(2)}`;
}

function parseJsonSafe(value: string): unknown {
  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
}

function prettyJson(value: unknown): string {
  if (value === undefined) {
    return 'null';
  }

  if (typeof value === 'string') {
    return value;
  }

  try {
    return JSON.stringify(value, null, 2);
  } catch {
    return String(value);
  }
}

function headersToObject(
  headers: Headers,
): Record<string, string> {
  const result: Record<string, string> = {};

  headers.forEach((value, key) => {
    result[key] = value;
  });

  return result;
}

function normalizeQrisData(
  value: QrisData | null | undefined,
): QrisData {
  return {
    orderId: value?.orderId,
    orderCode: value?.orderCode,

    orderStatus: value?.orderStatus,

    paymentMethod: value?.paymentMethod,
    paymentStatus: value?.paymentStatus,
    paymentStatusLabel:
      value?.paymentStatusLabel,

    transactionId:
      value?.transactionId ?? null,

    transactionStatus:
      value?.transactionStatus ?? null,

    paymentType:
      value?.paymentType ?? null,

    issuer:
      value?.issuer ?? null,

    qrUrl:
      value?.qrUrl ??
      value?.qr_url ??
      null,

    qrString:
      value?.qrString ??
      value?.qr_string ??
      null,

    expiryTime:
      value?.expiryTime ??
      value?.expiry_time ??
      null,

    paidAt:
      value?.paidAt ??
      value?.paymentPaidAt ??
      null,

    isExpired:
      value?.isExpired ?? false,

    total: Number(value?.total ?? 0),
    tax: Number(value?.tax ?? 0),
    service: Number(value?.service ?? 0),
  };
}

export default function MobileApiTesterPage() {
  const [baseUrl, setBaseUrl] = useState(
    '/api/mobile/v1',
  );

  const [email, setEmail] = useState(
    'kasir1@evognito.my.id',
  );

  const [password, setPassword] = useState('');

  const [accessToken, setAccessToken] =
    useState('');

  const [refreshToken, setRefreshToken] =
    useState('');

  const [products, setProducts] = useState<
    Product[]
  >([]);

  const [tables, setTables] = useState<
    PosTable[]
  >([]);

  const [
    selectedProductId,
    setSelectedProductId,
  ] = useState('');

  const [
    selectedTableCode,
    setSelectedTableCode,
  ] = useState('');

  const [quantity, setQuantity] =
    useState('1');

  const [memberQuery, setMemberQuery] =
    useState('');

  const [memberUserId, setMemberUserId] =
    useState('');

  const [memberId, setMemberId] =
    useState('');

  const [memberDebug, setMemberDebug] =
    useState<MemberData | null>(null);

  const [orderId, setOrderId] =
    useState('');

  const [orderCode, setOrderCode] =
    useState('');

  const [
    paymentMethod,
    setPaymentMethod,
  ] = useState<'cash' | 'qris'>('cash');

  const [
    amountReceived,
    setAmountReceived,
  ] = useState('100000');

  const [
    idempotencyKey,
    setIdempotencyKey,
  ] = useState(generateUuid());

  const [qrisDebug, setQrisDebug] =
    useState<QrisData | null>(null);

  const [qrisQrUrl, setQrisQrUrl] =
    useState('');

  const [
    qrisQrString,
    setQrisQrString,
  ] = useState('');

  const [
    qrisExpiryTime,
    setQrisExpiryTime,
  ] = useState('');

  const [
    pointsConfig,
    setPointsConfig,
  ] = useState<PointsConfigData | null>(
    null,
  );

  const [
    redeemPoints,
    setRedeemPoints,
  ] = useState('100');

  const [
    customMethod,
    setCustomMethod,
  ] = useState<HttpMethod>('GET');

  const [
    customPath,
    setCustomPath,
  ] = useState('/auth/me');

  const [
    customBody,
    setCustomBody,
  ] = useState('{}');

  const [
    customUseAuth,
    setCustomUseAuth,
  ] = useState(true);

  const [
    customUseIdempotency,
    setCustomUseIdempotency,
  ] = useState(false);

  const [logs, setLogs] = useState<
    RequestLog[]
  >([]);

  const [
    selectedLogId,
    setSelectedLogId,
  ] = useState<string | null>(null);

  const [
    lastResponse,
    setLastResponse,
  ] = useState<unknown>(null);

  const [running, setRunning] =
    useState(false);

  const normalizedBaseUrl = useMemo(
    () => baseUrl.replace(/\/+$/, ''),
    [baseUrl],
  );

  const selectedLog =
    logs.find(
      (item) =>
        item.id === selectedLogId,
    ) ??
    logs[0] ??
    null;

  useEffect(() => {
    const raw =
      localStorage.getItem(STORAGE_KEY);

    if (!raw) {
      return;
    }

    const parsed = parseJsonSafe(raw);

    if (
      typeof parsed !== 'object' ||
      parsed === null ||
      Array.isArray(parsed)
    ) {
      return;
    }

    const saved =
      parsed as Record<string, unknown>;

    setBaseUrl(
      String(
        saved.baseUrl ??
          '/api/mobile/v1',
      ),
    );

    setEmail(
      String(saved.email ?? ''),
    );

    setAccessToken(
      String(
        saved.accessToken ?? '',
      ),
    );

    setRefreshToken(
      String(
        saved.refreshToken ?? '',
      ),
    );

    setSelectedProductId(
      String(
        saved.selectedProductId ?? '',
      ),
    );

    setSelectedTableCode(
      String(
        saved.selectedTableCode ?? '',
      ),
    );

    setMemberQuery(
      String(
        saved.memberQuery ?? '',
      ),
    );

    setMemberUserId(
      String(
        saved.memberUserId ?? '',
      ),
    );

    setMemberId(
      String(saved.memberId ?? ''),
    );

    setOrderId(
      String(saved.orderId ?? ''),
    );

    setOrderCode(
      String(
        saved.orderCode ?? '',
      ),
    );

    setAmountReceived(
      String(
        saved.amountReceived ??
          '100000',
      ),
    );
  }, []);

  useEffect(() => {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        baseUrl,
        email,
        accessToken,
        refreshToken,
        selectedProductId,
        selectedTableCode,
        memberQuery,
        memberUserId,
        memberId,
        orderId,
        orderCode,
        amountReceived,
      }),
    );
  }, [
    baseUrl,
    email,
    accessToken,
    refreshToken,
    selectedProductId,
    selectedTableCode,
    memberQuery,
    memberUserId,
    memberId,
    orderId,
    orderCode,
    amountReceived,
  ]);

  function addLog(
    log: RequestLog,
  ): void {
    setLogs((current) =>
      [log, ...current].slice(0, 250),
    );

    setSelectedLogId(log.id);
  }

  function updateQrisState(
    data: QrisData | null | undefined,
  ): void {
    const normalized =
      normalizeQrisData(data);

    setQrisDebug(normalized);

    setQrisQrUrl(
      normalized.qrUrl ?? '',
    );

    setQrisQrString(
      normalized.qrString ?? '',
    );

    setQrisExpiryTime(
      normalized.expiryTime ?? '',
    );
  }

  async function request<T = unknown>(
    pathOrUrl: string,
    options: {
      method?: HttpMethod;
      body?: unknown;
      auth?: boolean;
      idempotency?: boolean;
      headers?: Record<string, string>;
    } = {},
  ): Promise<ApiResponse<T>> {
    const method =
      options.method ?? 'GET';

    const url =
      /^https?:\/\//i.test(pathOrUrl)
        ? pathOrUrl
        : `${normalizedBaseUrl}${
            pathOrUrl.startsWith('/')
              ? pathOrUrl
              : `/${pathOrUrl}`
          }`;

    const requestHeaders: Record<
      string,
      string
    > = {
      Accept: 'application/json',
      ...options.headers,
    };

    if (
      options.body !== undefined
    ) {
      requestHeaders[
        'Content-Type'
      ] = 'application/json';
    }

    if (
      options.auth !== false &&
      accessToken
    ) {
      requestHeaders.Authorization =
        `Bearer ${accessToken}`;
    }

    if (options.idempotency) {
      requestHeaders[
        'X-Idempotency-Key'
      ] = idempotencyKey;
    }

    const startedDate =
      new Date();

    const startedPerformance =
      performance.now();

    let response: Response | null =
      null;

    let responseBody: unknown =
      null;

    let errorName: string | null =
      null;

    let errorMessage:
      | string
      | null = null;

    let errorStack: string | null =
      null;

    try {
      response = await fetch(url, {
        method,
        headers: requestHeaders,

        body:
          options.body === undefined
            ? undefined
            : JSON.stringify(
                options.body,
              ),
      });

      const raw =
        await response.text();

      responseBody =
        raw.length === 0
          ? null
          : parseJsonSafe(raw);

      setLastResponse(responseBody);

      if (!response.ok) {
        const apiResponse =
          typeof responseBody ===
            'object' &&
          responseBody !== null &&
          !Array.isArray(
            responseBody,
          )
            ? (responseBody as ApiResponse)
            : null;

        errorMessage =
          apiResponse?.error
            ?.message ??
          apiResponse?.message ??
          `HTTP ${response.status} ${response.statusText}`;

        throw new Error(
          errorMessage,
        );
      }

      return responseBody as ApiResponse<T>;
    } catch (error) {
      errorName =
        error instanceof Error
          ? error.name
          : 'UnknownError';

      errorMessage =
        error instanceof Error
          ? error.message
          : String(error);

      errorStack =
        error instanceof Error
          ? error.stack ?? null
          : null;

      if (responseBody === null) {
        setLastResponse({
          success: false,
          error: {
            code:
              'CLIENT_OR_NETWORK_ERROR',
            message:
              errorMessage,
            details: null,
          },
        });
      }

      throw error;
    } finally {
      const finishedDate =
        new Date();

      addLog({
        id: generateUuid(),

        startedAt:
          startedDate.toISOString(),

        finishedAt:
          finishedDate.toISOString(),

        durationMs: Math.round(
          performance.now() -
            startedPerformance,
        ),

        method,
        url,

        requestHeaders,

        requestBody:
          options.body ?? null,

        status:
          response?.status ?? null,

        statusText:
          response?.statusText ??
          null,

        contentType:
          response?.headers.get(
            'content-type',
          ) ?? null,

        responseHeaders:
          response
            ? headersToObject(
                response.headers,
              )
            : {},

        responseBody,

        ok:
          response?.ok ?? false,

        errorName,
        errorMessage,
        errorStack,
      });
    }
  }

  async function run(
    action: () => Promise<void>,
  ): Promise<void> {
    if (running) {
      return;
    }

    setRunning(true);

    try {
      await action();
    } catch {
      // Error sudah disimpan ke log.
    } finally {
      setRunning(false);
    }
  }

  async function login(): Promise<void> {
    const result = await request<{
      tokens?: {
        accessToken?: string;
        refreshToken?: string;
      };

      accessToken?: string;
      refreshToken?: string;
    }>('/auth/login', {
      method: 'POST',
      auth: false,

      body: {
        email,
        password,
      },
    });

    const newAccessToken =
      result.data?.tokens
        ?.accessToken ??
      result.data?.accessToken;

    const newRefreshToken =
      result.data?.tokens
        ?.refreshToken ??
      result.data?.refreshToken;

    if (!newAccessToken) {
      throw new Error(
        'Response login tidak memiliki accessToken.',
      );
    }

    setAccessToken(
      newAccessToken,
    );

    setRefreshToken(
      newRefreshToken ?? '',
    );

    setPassword('');
  }

  async function refreshAccessToken(): Promise<void> {
    if (!refreshToken) {
      throw new Error(
        'Refresh token belum tersedia.',
      );
    }

    const result = await request<{
      tokens?: {
        accessToken?: string;
        refreshToken?: string;
      };

      accessToken?: string;
      refreshToken?: string;
    }>('/auth/refresh', {
      method: 'POST',
      auth: false,

      body: {
        refreshToken,
      },
    });

    const newAccessToken =
      result.data?.tokens
        ?.accessToken ??
      result.data?.accessToken;

    const newRefreshToken =
      result.data?.tokens
        ?.refreshToken ??
      result.data?.refreshToken;

    if (!newAccessToken) {
      throw new Error(
        'Response refresh tidak memiliki accessToken.',
      );
    }

    setAccessToken(
      newAccessToken,
    );

    setRefreshToken(
      newRefreshToken ??
        refreshToken,
    );
  }

  async function loadProducts(): Promise<void> {
    const result =
      await request<Product[]>(
        '/pos/products?page=1&limit=100',
      );

    const rows =
      result.data ?? [];

    setProducts(rows);

    if (
      !selectedProductId &&
      rows[0]
    ) {
      setSelectedProductId(
        String(rows[0].id),
      );
    }
  }

  async function loadTables(): Promise<void> {
    const result =
      await request<PosTable[]>(
        '/pos/tables',
      );

    const rows =
      result.data ?? [];

    setTables(rows);

    if (
      !selectedTableCode &&
      rows[0]
    ) {
      const code =
        rows[0].code ??
        rows[0].table_code ??
        '';

      setSelectedTableCode(
        String(code),
      );
    }
  }

  async function loadBootstrap(): Promise<void> {
    await request(
      '/pos/bootstrap',
    );

    await loadProducts();
    await loadTables();
    await loadPointsConfig();
  }

  async function searchMember(): Promise<void> {
    if (!memberQuery.trim()) {
      throw new Error(
        'Masukkan pencarian member.',
      );
    }

    const result =
      await request<MemberData[]>(
        `/members/search?query=${encodeURIComponent(
          memberQuery.trim(),
        )}`,
      );

    const member =
      result.data?.[0];

    if (!member) {
      throw new Error(
        'Member tidak ditemukan.',
      );
    }

    setMemberDebug(member);

    setMemberUserId(
      String(
        member.id ??
          member.userId ??
          '',
      ),
    );

    setMemberId(
      String(
        member.memberId ??
          member.member_id ??
          '',
      ),
    );
  }

  async function identifyMember(): Promise<void> {
    const identifier =
      memberId.trim() ||
      memberQuery.trim();

    if (!identifier) {
      throw new Error(
        'Member ID belum tersedia.',
      );
    }

    const result =
      await request<MemberData>(
        '/members/identify',
        {
          method: 'POST',

          body: {
            memberId:
              identifier,
          },
        },
      );

    const member =
      result.data;

    if (!member) {
      throw new Error(
        'Response identify tidak memiliki data member.',
      );
    }

    setMemberDebug(member);

    setMemberUserId(
      String(
        member.id ??
          member.userId ??
          '',
      ),
    );

    setMemberId(
      String(
        member.memberId ??
          member.member_id ??
          identifier,
      ),
    );
  }

  async function loadMemberDetail(): Promise<void> {
    if (!memberId) {
      throw new Error(
        'Member ID belum tersedia.',
      );
    }

    const result =
      await request<MemberData>(
        `/members/${encodeURIComponent(
          memberId,
        )}`,
      );

    setMemberDebug(
      result.data ?? null,
    );
  }

  async function loadMemberPoints(): Promise<void> {
    if (!memberId) {
      throw new Error(
        'Member ID belum tersedia.',
      );
    }

    await request(
      `/members/${encodeURIComponent(
        memberId,
      )}/points?page=1&limit=50`,
    );
  }

  async function loadPointsConfig(): Promise<void> {
    const result =
      await request<PointsConfigData>(
        '/members/points/config',
      );

    setPointsConfig(
      result.data ?? null,
    );
  }

  function buildOrderPayload(
    method: 'cash' | 'qris',
  ) {
    return {
      paymentMethod: method,

      tableCode:
        selectedTableCode ||
        null,

      discount: 0,
      discountId: null,

      customer: {
        userId:
          memberUserId
            ? Number(
                memberUserId,
              )
            : null,

        memberId:
          memberId || null,

        name:
          memberDebug?.name ??
          null,

        email:
          memberDebug?.email ??
          null,

        phone:
          memberDebug?.phone ??
          memberDebug
            ?.phoneNumber ??
          null,
      },

      items: [
        {
          menuItemId: Number(
            selectedProductId,
          ),

          quantity: Math.max(
            1,
            Number(quantity) || 1,
          ),

          selectedAddOns: [],
        },
      ],
    };
  }

  async function createOrder(
    method:
      | 'cash'
      | 'qris' = paymentMethod,
  ): Promise<number> {
    if (!selectedProductId) {
      throw new Error(
        'Pilih produk terlebih dahulu.',
      );
    }

    const result =
      await request<OrderCreateData>(
        '/pos/orders',
        {
          method: 'POST',
          idempotency: true,

          body:
            buildOrderPayload(
              method,
            ),
        },
      );

    const createdOrderId =
      result.data?.orderId;

    if (!createdOrderId) {
      throw new Error(
        'Response create order tidak memiliki orderId.',
      );
    }

    setOrderId(
      String(createdOrderId),
    );

    setOrderCode(
      result.data?.orderCode ??
        '',
    );

    if (method === 'qris') {
      updateQrisState(
        result.data,
      );
    }

    return createdOrderId;
  }

  async function recordPayment(
    targetOrderId:
      | string
      | number = orderId,
    method:
      | 'cash'
      | 'qris' = paymentMethod,
  ): Promise<void> {
    if (!targetOrderId) {
      throw new Error(
        'Order ID belum tersedia.',
      );
    }

    const result =
      await request<QrisData>(
        `/pos/orders/${targetOrderId}/payment`,
        {
          method: 'PATCH',

          body:
            method === 'cash'
              ? {
                  paymentMethod:
                    'cash',

                  amountReceived:
                    Number(
                      amountReceived,
                    ),
                }
              : {
                  paymentMethod:
                    'qris',
                },
        },
      );

    if (method === 'qris') {
      updateQrisState(
        result.data,
      );
    }
  }

  async function checkQrisStatus(): Promise<void> {
    if (!orderId) {
      throw new Error(
        'Order ID belum tersedia.',
      );
    }

    const result =
      await request<QrisData>(
        `/pos/orders/${orderId}/qris/status`,
      );

    updateQrisState(
      result.data,
    );
  }

  async function updateOrderStatus(
    status: string,
    targetOrderId:
      | string
      | number = orderId,
  ): Promise<void> {
    if (!targetOrderId) {
      throw new Error(
        'Order ID belum tersedia.',
      );
    }

    await request(
      `/pos/orders/${targetOrderId}/status`,
      {
        method: 'PATCH',

        body: {
          status,
        },
      },
    );
  }

  async function redeemMemberPoints(): Promise<void> {
    if (!memberId) {
      throw new Error(
        'Member ID belum tersedia.',
      );
    }

    const points =
      Number(redeemPoints);

    if (
      !Number.isInteger(points) ||
      points <= 0
    ) {
      throw new Error(
        'Jumlah points harus berupa angka bulat positif.',
      );
    }

    await request(
      `/members/${encodeURIComponent(
        memberId,
      )}/points/redeem`,
      {
        method: 'POST',
        idempotency: true,

        body: {
          points,

          orderId:
            orderId
              ? Number(orderId)
              : null,
        },
      },
    );
  }

  async function fullCashFlow(): Promise<void> {
    setPaymentMethod('cash');

    const createdOrderId =
      await createOrder('cash');

    await recordPayment(
      createdOrderId,
      'cash',
    );

    for (const status of [
      'confirmed',
      'preparing',
      'ready',
      'completed',
    ]) {
      await updateOrderStatus(
        status,
        createdOrderId,
      );
    }

    if (memberId) {
      await loadMemberPoints();
    }

    setIdempotencyKey(
      generateUuid(),
    );
  }

  async function fullQrisFlow(): Promise<void> {
    setPaymentMethod('qris');

    const createdOrderId =
      await createOrder('qris');

    await recordPayment(
      createdOrderId,
      'qris',
    );

    setOrderId(
      String(createdOrderId),
    );

    const statusResult =
      await request<QrisData>(
        `/pos/orders/${createdOrderId}/qris/status`,
      );

    updateQrisState(
      statusResult.data,
    );

    setIdempotencyKey(
      generateUuid(),
    );
  }

  async function sendCustomRequest(): Promise<void> {
    let parsedBody:
      | unknown
      | undefined = undefined;

    if (
      customMethod !== 'GET' &&
      customMethod !== 'DELETE'
    ) {
      parsedBody =
        parseJsonSafe(
          customBody,
        );

      if (
        typeof parsedBody ===
        'string'
      ) {
        throw new Error(
          'Custom body harus berupa JSON valid.',
        );
      }
    }

    await request(
      customPath,
      {
        method:
          customMethod,

        body:
          parsedBody,

        auth:
          customUseAuth,

        idempotency:
          customUseIdempotency,
      },
    );
  }

  function exportLogs(): void {
    const blob = new Blob(
      [
        JSON.stringify(
          {
            exportedAt:
              new Date().toISOString(),

            baseUrl:
              normalizedBaseUrl,

            logs,
          },
          null,
          2,
        ),
      ],
      {
        type:
          'application/json',
      },
    );

    const objectUrl =
      URL.createObjectURL(blob);

    const anchor =
      document.createElement(
        'a',
      );

    anchor.href =
      objectUrl;

    anchor.download =
      `ekasir-mobile-api-logs-${Date.now()}.json`;

    anchor.click();

    URL.revokeObjectURL(
      objectUrl,
    );
  }

  return (
    <main className="min-h-screen bg-slate-100 p-4 text-slate-900 md:p-8">
      <div className="mx-auto max-w-[1700px] space-y-6">
        <header className="rounded-3xl bg-slate-950 p-6 text-white shadow-xl">
          <p className="text-xs font-black uppercase tracking-[0.25em] text-emerald-400">
            EKASIR Developer Tools
          </p>

          <h1 className="mt-2 text-3xl font-black">
            Mobile API Tester
          </h1>

          <p className="mt-3 max-w-5xl text-sm leading-relaxed text-slate-400">
            Pengujian autentikasi, produk,
            meja, member, order, cash,
            QRIS, loyalty points,
            idempotency, custom request,
            dan detail error API.
          </p>
        </header>

        <Panel title="Koneksi dan autentikasi">
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <Input
              label="Base URL"
              value={baseUrl}
              onChange={
                setBaseUrl
              }
            />

            <Input
              label="Email"
              value={email}
              onChange={
                setEmail
              }
            />

            <Input
              label="Password"
              type="password"
              value={password}
              onChange={
                setPassword
              }
            />

            <Input
              label="Access token"
              value={accessToken}
              onChange={
                setAccessToken
              }
            />
          </div>

          <ButtonRow>
            <Button
              primary
              disabled={
                running
              }
              onClick={() =>
                run(login)
              }
            >
              Login
            </Button>

            <Button
              disabled={
                running ||
                !refreshToken
              }
              onClick={() =>
                run(
                  refreshAccessToken,
                )
              }
            >
              Refresh token
            </Button>

            <Button
              disabled={
                running ||
                !accessToken
              }
              onClick={() =>
                run(async () => {
                  await request(
                    '/auth/me',
                  );
                })
              }
            >
              Auth me
            </Button>

            <Button
              disabled={
                running ||
                !accessToken
              }
              onClick={() =>
                run(
                  loadBootstrap,
                )
              }
            >
              Bootstrap lengkap
            </Button>
          </ButtonRow>
        </Panel>

        <div className="grid gap-6 xl:grid-cols-4">
          <Panel title="Produk dan meja">
            <ButtonRow>
              <Button
                disabled={
                  running ||
                  !accessToken
                }
                onClick={() =>
                  run(
                    loadProducts,
                  )
                }
              >
                Muat produk
              </Button>

              <Button
                disabled={
                  running ||
                  !accessToken
                }
                onClick={() =>
                  run(
                    loadTables,
                  )
                }
              >
                Muat meja
              </Button>
            </ButtonRow>

            <Select
              label="Produk"
              value={
                selectedProductId
              }
              onChange={
                setSelectedProductId
              }
              options={[
                {
                  value: '',
                  label:
                    'Pilih produk',
                },

                ...products.map(
                  (product) => ({
                    value:
                      String(
                        product.id,
                      ),

                    label:
                      `#${product.id} — ${product.name} — Rp${Number(
                        product.price ??
                          0,
                      ).toLocaleString(
                        'id-ID',
                      )}`,
                  }),
                ),
              ]}
            />

            <Select
              label="Meja"
              value={
                selectedTableCode
              }
              onChange={
                setSelectedTableCode
              }
              options={[
                {
                  value: '',
                  label:
                    'Walk-in / tanpa meja',
                },

                ...tables.map(
                  (table) => {
                    const code =
                      String(
                        table.code ??
                          table.table_code ??
                          '',
                      );

                    const name =
                      table.name ??
                      table.table_name ??
                      code;

                    return {
                      value:
                        code,

                      label:
                        `${name} — ${code}`,
                    };
                  },
                ),
              ]}
            />

            <Input
              label="Quantity"
              type="number"
              value={quantity}
              onChange={
                setQuantity
              }
            />
          </Panel>

          <Panel title="Member">
            <Input
              label="Cari member"
              value={
                memberQuery
              }
              onChange={
                setMemberQuery
              }
              placeholder="ID, nama, email, telepon"
            />

            <ButtonRow>
              <Button
                disabled={
                  running ||
                  !accessToken ||
                  !memberQuery
                }
                onClick={() =>
                  run(
                    searchMember,
                  )
                }
              >
                Search
              </Button>

              <Button
                disabled={
                  running ||
                  !accessToken ||
                  !(
                    memberId ||
                    memberQuery
                  )
                }
                onClick={() =>
                  run(
                    identifyMember,
                  )
                }
              >
                Identify
              </Button>
            </ButtonRow>

            <Input
              label="User ID"
              value={
                memberUserId
              }
              onChange={
                setMemberUserId
              }
            />

            <Input
              label="Member ID"
              value={memberId}
              onChange={
                setMemberId
              }
            />

            <ButtonRow>
              <Button
                disabled={
                  running ||
                  !accessToken ||
                  !memberId
                }
                onClick={() =>
                  run(
                    loadMemberDetail,
                  )
                }
              >
                Detail
              </Button>

              <Button
                disabled={
                  running ||
                  !accessToken ||
                  !memberId
                }
                onClick={() =>
                  run(
                    loadMemberPoints,
                  )
                }
              >
                History points
              </Button>
            </ButtonRow>

            <CodeValue
              label="Member Debug"
              value={
                prettyJson(
                  memberDebug,
                )
              }
            />
          </Panel>

          <Panel title="Order dan payment">
            <Select
              label="Payment method"
              value={
                paymentMethod
              }
              onChange={(
                value,
              ) =>
                setPaymentMethod(
                  value as
                    | 'cash'
                    | 'qris',
                )
              }
              options={[
                {
                  value: 'cash',
                  label: 'Cash',
                },
                {
                  value: 'qris',
                  label: 'QRIS',
                },
              ]}
            />

            <Input
              label="Amount received"
              type="number"
              value={
                amountReceived
              }
              onChange={
                setAmountReceived
              }
            />

            <Input
              label="Idempotency Key"
              value={
                idempotencyKey
              }
              onChange={
                setIdempotencyKey
              }
            />

            <ButtonRow>
              <Button
                disabled={running}
                onClick={() =>
                  setIdempotencyKey(
                    generateUuid(),
                  )
                }
              >
                Generate key
              </Button>

              <Button
                primary
                disabled={
                  running ||
                  !accessToken ||
                  !selectedProductId
                }
                onClick={() =>
                  run(async () => {
                    await createOrder();
                  })
                }
              >
                Create order
              </Button>
            </ButtonRow>

            <Input
              label="Order ID"
              value={orderId}
              onChange={
                setOrderId
              }
            />

            <Input
              label="Order code"
              value={
                orderCode
              }
              onChange={
                setOrderCode
              }
            />

            <ButtonRow>
              <Button
                disabled={
                  running ||
                  !accessToken ||
                  !orderId
                }
                onClick={() =>
                  run(async () => {
                    await recordPayment();
                  })
                }
              >
                PATCH payment
              </Button>

              <Button
                disabled={
                  running ||
                  !accessToken ||
                  !orderId
                }
                onClick={() =>
                  run(
                    checkQrisStatus,
                  )
                }
              >
                Check QRIS
              </Button>
            </ButtonRow>
          </Panel>

          <Panel title="Loyalty points">
            <Button
              disabled={
                running ||
                !accessToken
              }
              onClick={() =>
                run(
                  loadPointsConfig,
                )
              }
            >
              Muat points config
            </Button>

            <CodeValue
              label="Points Config"
              value={
                prettyJson(
                  pointsConfig,
                )
              }
            />

            <Input
              label="Jumlah points redeem"
              type="number"
              value={
                redeemPoints
              }
              onChange={
                setRedeemPoints
              }
            />

            <Button
              primary
              disabled={
                running ||
                !accessToken ||
                !memberId
              }
              onClick={() =>
                run(
                  redeemMemberPoints,
                )
              }
            >
              Redeem points
            </Button>
          </Panel>
        </div>

        <Panel title="Status order dan full flow">
          <ButtonRow>
            {[
              'confirmed',
              'preparing',
              'ready',
              'completed',
              'cancelled',
            ].map((status) => (
              <Button
                key={status}
                disabled={
                  running ||
                  !accessToken ||
                  !orderId
                }
                onClick={() =>
                  run(
                    async () => {
                      await updateOrderStatus(
                        status,
                      );
                    },
                  )
                }
              >
                {status}
              </Button>
            ))}

            <Button
              primary
              disabled={
                running ||
                !accessToken ||
                !selectedProductId
              }
              onClick={() =>
                run(
                  fullCashFlow,
                )
              }
            >
              Full cash flow
            </Button>

            <Button
              primary
              disabled={
                running ||
                !accessToken ||
                !selectedProductId
              }
              onClick={() =>
                run(
                  fullQrisFlow,
                )
              }
            >
              Full QRIS flow
            </Button>
          </ButtonRow>
        </Panel>

        <Panel title="QRIS Debug">
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <CodeValue
              label="Order ID"
              value={String(
                qrisDebug
                  ?.orderId ??
                  orderId ??
                  '-',
              )}
            />

            <CodeValue
              label="Order Code"
              value={
                qrisDebug
                  ?.orderCode ??
                orderCode ??
                '-'
              }
            />

            <CodeValue
              label="Order Status"
              value={
                qrisDebug
                  ?.orderStatus ??
                '-'
              }
            />

            <CodeValue
              label="Payment Method"
              value={
                qrisDebug
                  ?.paymentMethod ??
                '-'
              }
            />

            <CodeValue
              label="Payment Status"
              value={
                qrisDebug
                  ?.paymentStatus ??
                '-'
              }
            />

            <CodeValue
              label="Status Label"
              value={
                qrisDebug
                  ?.paymentStatusLabel ??
                '-'
              }
            />

            <CodeValue
              label="Transaction ID"
              value={
                qrisDebug
                  ?.transactionId ??
                '-'
              }
            />

            <CodeValue
              label="Transaction Status"
              value={
                qrisDebug
                  ?.transactionStatus ??
                '-'
              }
            />

            <CodeValue
              label="Payment Type"
              value={
                qrisDebug
                  ?.paymentType ??
                '-'
              }
            />

            <CodeValue
              label="Issuer"
              value={
                qrisDebug
                  ?.issuer ??
                '-'
              }
            />

            <CodeValue
              label="Expiry Time"
              value={
                qrisExpiryTime ||
                qrisDebug
                  ?.expiryTime ||
                '-'
              }
            />

            <CodeValue
              label="Paid At"
              value={
                qrisDebug
                  ?.paidAt ??
                '-'
              }
            />

            <CodeValue
              label="Expired"
              value={String(
                qrisDebug
                  ?.isExpired ??
                  false,
              )}
            />

            <CodeValue
              label="Total"
              value={`Rp${Number(
                qrisDebug
                  ?.total ??
                  0,
              ).toLocaleString(
                'id-ID',
              )}`}
            />

            <CodeValue
              label="Tax"
              value={`Rp${Number(
                qrisDebug
                  ?.tax ??
                  0,
              ).toLocaleString(
                'id-ID',
              )}`}
            />

            <CodeValue
              label="Service"
              value={`Rp${Number(
                qrisDebug
                  ?.service ??
                  0,
              ).toLocaleString(
                'id-ID',
              )}`}
            />
          </div>

          <CodeValue
            label="QR URL"
            value={
              qrisQrUrl ||
              qrisDebug?.qrUrl ||
              '-'
            }
          />

          <CodeValue
            label="QR String"
            value={
              qrisQrString ||
              qrisDebug
                ?.qrString ||
              '-'
            }
          />

          <CodeValue
            label="Full QRIS Response"
            value={
              prettyJson(
                qrisDebug,
              )
            }
          />

          {qrisQrUrl && (
            <div className="rounded-2xl border border-slate-200 bg-white p-4">
              <p className="mb-3 text-xs font-black uppercase tracking-wider text-slate-500">
                QR Image Preview
              </p>

              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={qrisQrUrl}
                alt="QRIS"
                className="h-64 w-64 rounded-xl border bg-white object-contain p-3"
              />
            </div>
          )}
        </Panel>

        <Panel title="Custom request">
          <div className="grid gap-4 md:grid-cols-3">
            <Select
              label="Method"
              value={
                customMethod
              }
              onChange={(
                value,
              ) =>
                setCustomMethod(
                  value as HttpMethod,
                )
              }
              options={[
                'GET',
                'POST',
                'PATCH',
                'PUT',
                'DELETE',
              ].map(
                (method) => ({
                  value:
                    method,
                  label:
                    method,
                }),
              )}
            />

            <Input
              label="Path atau URL"
              value={
                customPath
              }
              onChange={
                setCustomPath
              }
            />

            <div className="flex items-end gap-5 pb-3">
              <Checkbox
                label="Bearer token"
                checked={
                  customUseAuth
                }
                onChange={
                  setCustomUseAuth
                }
              />

              <Checkbox
                label="Idempotency"
                checked={
                  customUseIdempotency
                }
                onChange={
                  setCustomUseIdempotency
                }
              />
            </div>
          </div>

          <label className="block">
            <span className="text-xs font-black uppercase tracking-wider text-slate-500">
              JSON body
            </span>

            <textarea
              value={
                customBody
              }
              onChange={(
                event,
              ) =>
                setCustomBody(
                  event.target
                    .value,
                )
              }
              className="mt-2 min-h-44 w-full rounded-xl border border-slate-200 p-3 font-mono text-xs outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/10"
            />
          </label>

          <Button
            primary
            disabled={running}
            onClick={() =>
              run(
                sendCustomRequest,
              )
            }
          >
            Kirim custom request
          </Button>
        </Panel>

        <div className="grid gap-6 xl:grid-cols-2">
          <Panel
            title="Response terakhir"
            dark
          >
            <pre className="max-h-[700px] overflow-auto whitespace-pre-wrap break-all rounded-2xl bg-black/40 p-4 text-xs leading-relaxed text-emerald-300">
              {lastResponse !==
              null
                ? prettyJson(
                    lastResponse,
                  )
                : 'Belum ada response.'}
            </pre>
          </Panel>

          <Panel title="Request logs">
            <ButtonRow>
              <Button
                disabled={
                  logs.length === 0
                }
                onClick={
                  exportLogs
                }
              >
                Export JSON
              </Button>

              <Button
                danger
                disabled={
                  logs.length === 0
                }
                onClick={() => {
                  setLogs([]);
                  setSelectedLogId(
                    null,
                  );
                }}
              >
                Hapus logs
              </Button>
            </ButtonRow>

            <div className="mt-4 max-h-[700px] space-y-2 overflow-auto">
              {logs.length === 0 && (
                <p className="rounded-xl bg-slate-100 p-4 text-sm text-slate-500">
                  Belum ada request.
                </p>
              )}

              {logs.map(
                (log) => (
                  <button
                    key={log.id}
                    type="button"
                    onClick={() =>
                      setSelectedLogId(
                        log.id,
                      )
                    }
                    className={`w-full rounded-xl border p-3 text-left transition ${
                      selectedLog?.id ===
                      log.id
                        ? 'border-emerald-500 bg-emerald-50'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="rounded-md bg-slate-950 px-2 py-1 text-[10px] font-black text-white">
                        {log.method}
                      </span>

                      <span className="min-w-0 flex-1 truncate text-xs font-bold">
                        {log.url}
                      </span>

                      <span
                        className={`text-xs font-black ${
                          log.ok
                            ? 'text-emerald-700'
                            : 'text-red-600'
                        }`}
                      >
                        {log.status ??
                          'NETWORK'}
                      </span>
                    </div>

                    <p className="mt-2 text-[10px] text-slate-500">
                      {
                        log.durationMs
                      }{' '}
                      ms ·{' '}
                      {log.contentType ??
                        'no content-type'}
                    </p>

                    {log.errorMessage && (
                      <p className="mt-2 text-xs font-bold text-red-600">
                        {
                          log.errorMessage
                        }
                      </p>
                    )}
                  </button>
                ),
              )}
            </div>
          </Panel>
        </div>

        {selectedLog && (
          <Panel title="Detail request terpilih">
            <div className="grid gap-4 xl:grid-cols-2">
              <CodeValue
                label="URL"
                value={
                  selectedLog.url
                }
              />

              <CodeValue
                label="Method"
                value={
                  selectedLog.method
                }
              />

              <CodeValue
                label="HTTP Status"
                value={`${selectedLog.status ?? '-'} ${
                  selectedLog.statusText ??
                  ''
                }`}
              />

              <CodeValue
                label="Duration"
                value={`${selectedLog.durationMs} ms`}
              />

              <CodeValue
                label="Started"
                value={
                  selectedLog.startedAt
                }
              />

              <CodeValue
                label="Finished"
                value={
                  selectedLog.finishedAt
                }
              />

              <CodeValue
                label="Content Type"
                value={
                  selectedLog.contentType ??
                  '-'
                }
              />

              <CodeValue
                label="Request Headers"
                value={
                  prettyJson(
                    selectedLog
                      .requestHeaders,
                  )
                }
              />

              <CodeValue
                label="Request Payload"
                value={
                  prettyJson(
                    selectedLog
                      .requestBody,
                  )
                }
              />

              <CodeValue
                label="Response Headers"
                value={
                  prettyJson(
                    selectedLog
                      .responseHeaders,
                  )
                }
              />

              <CodeValue
                label="Response Body"
                value={
                  prettyJson(
                    selectedLog
                      .responseBody,
                  )
                }
              />

              <CodeValue
                label="Error Detail"
                value={
                  prettyJson({
                    name:
                      selectedLog
                        .errorName,

                    message:
                      selectedLog
                        .errorMessage,

                    stack:
                      selectedLog
                        .errorStack,
                  })
                }
              />
            </div>
          </Panel>
        )}
      </div>
    </main>
  );
}

function Panel({
  title,
  children,
  dark = false,
}: {
  title: string;
  children: ReactNode;
  dark?: boolean;
}) {
  return (
    <section
      className={`space-y-4 rounded-3xl p-5 shadow-sm ${
        dark
          ? 'bg-slate-950 text-white'
          : 'bg-white'
      }`}
    >
      <h2 className="text-lg font-black">
        {title}
      </h2>

      {children}
    </section>
  );
}

function Input({
  label,
  value,
  onChange,
  type = 'text',
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (
    value: string,
  ) => void;
  type?:
    | 'text'
    | 'password'
    | 'number';
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="text-xs font-black uppercase tracking-wider text-slate-500">
        {label}
      </span>

      <input
        type={type}
        value={value}
        placeholder={
          placeholder
        }
        onChange={(event) =>
          onChange(
            event.target.value,
          )
        }
        className="mt-2 w-full rounded-xl border border-slate-200 px-3 py-3 text-sm outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/10"
      />
    </label>
  );
}

function Select({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (
    value: string,
  ) => void;

  options: Array<{
    value: string;
    label: string;
  }>;
}) {
  return (
    <label className="block">
      <span className="text-xs font-black uppercase tracking-wider text-slate-500">
        {label}
      </span>

      <select
        value={value}
        onChange={(event) =>
          onChange(
            event.target.value,
          )
        }
        className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm outline-none focus:border-emerald-600"
      >
        {options.map(
          (option) => (
            <option
              key={`${option.value}-${option.label}`}
              value={
                option.value
              }
            >
              {option.label}
            </option>
          ),
        )}
      </select>
    </label>
  );
}

function Button({
  children,
  onClick,
  disabled,
  primary = false,
  danger = false,
}: {
  children: ReactNode;
  onClick: () => void;
  disabled?: boolean;
  primary?: boolean;
  danger?: boolean;
}) {
  const style = danger
    ? 'bg-red-600 text-white hover:bg-red-700'
    : primary
      ? 'bg-emerald-700 text-white hover:bg-emerald-800'
      : 'bg-slate-100 text-slate-900 hover:bg-slate-200';

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`rounded-xl px-4 py-3 text-sm font-black transition disabled:cursor-not-allowed disabled:opacity-40 ${style}`}
    >
      {children}
    </button>
  );
}

function ButtonRow({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {children}
    </div>
  );
}

function Checkbox({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (
    value: boolean,
  ) => void;
}) {
  return (
    <label className="flex items-center gap-2 text-sm font-bold">
      <input
        type="checkbox"
        checked={checked}
        onChange={(event) =>
          onChange(
            event.target.checked,
          )
        }
      />

      {label}
    </label>
  );
}

function CodeValue({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  async function copy(): Promise<void> {
    try {
      await navigator.clipboard.writeText(
        value,
      );
    } catch {
      // Clipboard dapat gagal bila halaman bukan HTTPS.
    }
  }

  return (
    <div className="min-w-0 rounded-2xl border border-slate-200 bg-slate-50 p-4 text-slate-900">
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-xs font-black uppercase tracking-wider text-slate-500">
          {label}
        </p>

        <button
          type="button"
          onClick={copy}
          className="rounded-lg bg-white px-2 py-1 text-[10px] font-black shadow-sm hover:bg-slate-100"
        >
          Copy
        </button>
      </div>

      <pre className="max-h-72 overflow-auto whitespace-pre-wrap break-all text-xs leading-relaxed">
        {value || '-'}
      </pre>
    </div>
  );
}