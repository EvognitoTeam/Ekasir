export type KioskStep = 'welcome' | 'service-type' | 'catalog' | 'cart' | 'payment' | 'qris' | 'success';
export type KioskServiceType = 'dine-in' | 'takeaway';
export type KioskPaymentMethod = 'cash' | 'qris';
export type KioskCategory = { id: number | string; name: string; slug?: string };
export type KioskAddOn = { id: number | string; name: string; price: number };
export type KioskProduct = {
  id: number | string;
  name: string;
  description?: string | null;
  price: number;
  imageUrl?: string | null;
  categoryId?: number | string | null;
  isAvailable?: boolean;
  stock?: number | null;
  addOns?: KioskAddOn[];
};
export type KioskCartItem = {
  lineId: string;
  productId: number | string;
  name: string;
  imageUrl?: string | null;
  quantity: number;
  basePrice: number;
  addOns: KioskAddOn[];
  notes?: string;
};
export type KioskQrisData = {
  transactionId: string;
  qrUrl: string;
  qrString?: string | null;
  expiryTime?: string | null;
};
