'use client';

import {
  Plus,
} from 'lucide-react';

import type {
  KioskProduct,
} from './types';

type KioskProductCardProps = {
  product: KioskProduct;
  onClick: (
    product: KioskProduct,
  ) => void;
};

export default function KioskProductCard({
  product,
  onClick,
}: KioskProductCardProps) {
  const unavailable =
    product.isAvailable === false ||
    (
      product.stock !== null &&
      product.stock !== undefined &&
      product.stock <= 0
    );

  return (
    <button
      type="button"
      disabled={unavailable}
      onClick={() =>
        onClick(product)
      }
      className="group flex min-h-[250px] overflow-hidden rounded-[2rem] border border-stone-200 bg-white text-left shadow-sm transition active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-50"
    >
      <div className="relative flex w-[42%] shrink-0 items-center justify-center overflow-hidden bg-stone-50 p-5">
        <img
          src={
            product.imageUrl ||
            '/logo.png'
          }
          alt={product.name}
          className="h-40 w-40 object-contain transition duration-300 group-hover:scale-105"
          onError={(
            event,
          ) => {
            event.currentTarget.src =
              '/logo.png';
          }}
        />

        {unavailable && (
          <div className="absolute inset-0 flex items-center justify-center bg-stone-950/65 text-base font-black uppercase tracking-widest text-white">
            Habis
          </div>
        )}
      </div>

      <div className="flex min-w-0 flex-1 flex-col justify-center p-6">
        <p className="line-clamp-2 text-2xl font-black leading-tight text-stone-950">
          {product.name}
        </p>

        {product.description && (
          <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-stone-500">
            {product.description}
          </p>
        )}

        <div className="mt-6 flex items-center justify-between gap-4">
          <p className="text-2xl font-black text-amber-700">
            Rp
            {product.price.toLocaleString(
              'id-ID',
            )}
          </p>

          <span className="flex h-13 w-13 shrink-0 items-center justify-center rounded-2xl bg-stone-950 p-3 text-white">
            <Plus className="h-6 w-6" />
          </span>
        </div>
      </div>
    </button>
  );
}
