'use client';

import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';

type Props = {
  children: ReactNode;
  idleMs?: number;
  countdownSeconds?: number;
  disabled?: boolean;
  onReset: () => void;
};

export default function KioskIdleGuard({
  children,
  idleMs = 90000,
  countdownSeconds = 15,
  disabled = false,
  onReset,
}: Props) {
  const [warningOpen, setWarningOpen] = useState(false);
  const [remaining, setRemaining] = useState(countdownSeconds);
  const idleTimer = useRef<number | null>(null);

  const resetIdleTimer = useCallback(() => {
    if (disabled) return;
    if (idleTimer.current) window.clearTimeout(idleTimer.current);
    setWarningOpen(false);
    setRemaining(countdownSeconds);
    idleTimer.current = window.setTimeout(() => setWarningOpen(true), idleMs);
  }, [countdownSeconds, disabled, idleMs]);

  useEffect(() => {
    if (disabled) return;
    const events = ['pointerdown', 'pointermove', 'keydown', 'touchstart'] as const;
    events.forEach((name) => window.addEventListener(name, resetIdleTimer));
    resetIdleTimer();
    return () => {
      events.forEach((name) => window.removeEventListener(name, resetIdleTimer));
      if (idleTimer.current) window.clearTimeout(idleTimer.current);
    };
  }, [disabled, resetIdleTimer]);

  useEffect(() => {
    if (!warningOpen) return;
    const timer = window.setInterval(() => {
      setRemaining((value) => {
        if (value <= 1) {
          window.clearInterval(timer);
          onReset();
          return 0;
        }
        return value - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [onReset, warningOpen]);

  return (
    <>
      {children}
      {warningOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-stone-950/80 p-8 backdrop-blur-md">
          <div className="w-full max-w-2xl rounded-[2.5rem] bg-white p-10 text-center">
            <p className="text-sm font-bold uppercase tracking-[0.28em] text-amber-600">Sesi hampir berakhir</p>
            <h2 className="mt-5 text-5xl font-black">Masih memesan?</h2>
            <p className="mt-5 text-xl text-stone-500">Pesanan akan direset dalam {remaining} detik.</p>
            <button type="button" onClick={resetIdleTimer} className="mt-8 min-h-20 w-full rounded-2xl bg-stone-950 text-2xl font-black text-white">Ya, lanjutkan</button>
          </div>
        </div>
      )}
    </>
  );
}
