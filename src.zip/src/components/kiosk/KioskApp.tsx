'use client';

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react';

import {
  KioskCatalog,
  KioskIdleGuard,
  KioskOrderSuccess,
  KioskPaymentMethod,
  KioskProductModal,
  KioskQrisPayment,
  KioskServiceType,
  KioskWelcome,
} from '@/components/kiosk';

import type {
  KioskCartItem,
  KioskCategory,
  KioskPaymentMethod as PaymentMethod,
  KioskProduct,
  KioskQrisData,
  KioskServiceType as ServiceType,
  KioskStep,
} from '@/components/kiosk/types';

type BootstrapResponse = {
  success: boolean;
  message?: string;
  data?: {
    store: {
      name: string;
      logoUrl?: string | null;
      tagline?: string | null;
      mitraId: number;
      branchId: number | null;
    };
    categories: KioskCategory[];
    products: KioskProduct[];
  };
};

type CreateOrderResponse = {
  success: boolean;
  message?: string;
  data?: {
    orderId: number;
    orderCode: string;
    paymentMethod: PaymentMethod;
    paymentStatus: string;
    paymentStatusLabel?: string;
    grandTotal: number;
    qris?: KioskQrisData | null;
  };
};

type StatusResponse = {
  success: boolean;
  message?: string;
  data?: {
    paymentStatus?: string;
    paymentStatusLabel?: string;
  };
};

type KioskAppProps = {
  mitraSlug: string;
  branchSlug?: string;
};

type PaymentState =
  | 'pending'
  | 'paid'
  | 'expired'
  | 'failed';

const DEFAULT_STORE_NAME =
  'EKASIR';

function buildScopeQuery(
  mitraSlug: string,
  branchSlug?: string,
) {
  const query =
    new URLSearchParams({
      slug:
        mitraSlug,
    });

  if (branchSlug) {
    query.set(
      'branch_slug',
      branchSlug,
    );
  }

  return query;
}

function createLineId(
  productId:
    number | string,
) {
  return [
    String(productId),
    Date.now(),
    Math.random()
      .toString(36)
      .slice(2, 8),
  ].join('-');
}

function normalizePaymentState(
  label?: string,
): PaymentState {
  const normalized =
    String(
      label ?? '',
    )
      .trim()
      .toLowerCase();

  if (
    [
      'paid',
      'settlement',
      'capture',
    ].includes(
      normalized,
    )
  ) {
    return 'paid';
  }

  if (
    [
      'expired',
      'expire',
    ].includes(
      normalized,
    )
  ) {
    return 'expired';
  }

  if (
    [
      'failed',
      'deny',
      'cancel',
      'failure',
    ].includes(
      normalized,
    )
  ) {
    return 'failed';
  }

  return 'pending';
}

export default function KioskApp({
  mitraSlug,
  branchSlug,
}: KioskAppProps) {
  const [step, setStep] =
    useState<KioskStep>(
      'welcome',
    );

  const [store, setStore] =
    useState({
      name:
        DEFAULT_STORE_NAME,
      logoUrl:
        null as string | null,
      tagline:
        null as string | null,
      mitraId:
        0,
      branchId:
        null as number | null,
    });

  const [
    categories,
    setCategories,
  ] =
    useState<KioskCategory[]>(
      [],
    );

  const [
    products,
    setProducts,
  ] =
    useState<KioskProduct[]>(
      [],
    );

  const [
    activeCategoryId,
    setActiveCategoryId,
  ] =
    useState<
      number | string | null
    >(null);

  const [
    serviceType,
    setServiceType,
  ] =
    useState<ServiceType | null>(
      null,
    );

  const [cart, setCart] =
    useState<KioskCartItem[]>(
      [],
    );

  const [
    selectedProduct,
    setSelectedProduct,
  ] =
    useState<KioskProduct | null>(
      null,
    );

  const [
    recentlyAdded,
    setRecentlyAdded,
  ] =
    useState<{
      lineId: string;
      productName: string;
    } | null>(null);

  const [
    paymentMethod,
    setPaymentMethod,
  ] =
    useState<PaymentMethod | null>(
      null,
    );

  const [
    paymentStatus,
    setPaymentStatus,
  ] =
    useState<PaymentState>(
      'pending',
    );

  const [qris, setQris] =
    useState<KioskQrisData | null>(
      null,
    );

  const [
    createdOrder,
    setCreatedOrder,
  ] =
    useState<{
      id: number;
      code: string;
    } | null>(null);

  const [isLoading, setIsLoading] =
    useState(true);

  const [
    isSubmitting,
    setIsSubmitting,
  ] =
    useState(false);

  const [error, setError] =
    useState<string | null>(null);

  const scopeQuery =
    useMemo(
      () =>
        buildScopeQuery(
          mitraSlug,
          branchSlug,
        ),
      [
        mitraSlug,
        branchSlug,
      ],
    );

  const loadBootstrap =
    useCallback(async () => {
      setIsLoading(true);
      setError(null);

      try {
        const response =
          await fetch(
            `/api/kiosk/bootstrap?${scopeQuery.toString()}`,
            {
              credentials:
                'include',
              cache:
                'no-store',
              headers: {
                Accept:
                  'application/json',
              },
            },
          );

        const result =
          await response.json() as
            BootstrapResponse;

        if (
          !response.ok ||
          !result.success ||
          !result.data
        ) {
          throw new Error(
            result.message ||
              'Gagal memuat data kiosk.',
          );
        }

        setStore({
          name:
            result.data.store
              .name,
          logoUrl:
            result.data.store
              .logoUrl ??
            null,
          tagline:
            result.data.store
              .tagline ??
            null,
          mitraId:
            Number(
              result.data.store
                .mitraId,
            ),
          branchId:
            result.data.store
              .branchId ??
            null,
        });

        setCategories(
          result.data.categories ??
            [],
        );

        setProducts(
          result.data.products ??
            [],
        );
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Gagal memuat kiosk.',
        );
      } finally {
        setIsLoading(false);
      }
    }, [scopeQuery]);

  useEffect(() => {
    /*
     * Menjadwalkan bootstrap di callback timer agar update state
     * tidak dijalankan secara sinkron di body effect.
     */
    const timer =
      window.setTimeout(
        () => {
          void loadBootstrap();
        },
        0,
      );

    return () => {
      window.clearTimeout(
        timer,
      );
    };
  }, [loadBootstrap]);

  const filteredProducts =
    useMemo(
      () =>
        activeCategoryId ===
        null
          ? products
          : products.filter(
              (product) =>
                product.categoryId ===
                activeCategoryId,
            ),
      [
        activeCategoryId,
        products,
      ],
    );

  const cartQuantity =
    useMemo(
      () =>
        cart.reduce(
          (
            total,
            item,
          ) =>
            total +
            item.quantity,
          0,
        ),
      [cart],
    );

  const subtotal =
    useMemo(
      () =>
        cart.reduce(
          (
            total,
            item,
          ) => {
            const addOnTotal =
              item.addOns.reduce(
                (
                  sum,
                  addOn,
                ) =>
                  sum +
                  addOn.price,
                0,
              );

            return (
              total +
              (
                item.basePrice +
                addOnTotal
              ) *
                item.quantity
            );
          },
          0,
        ),
      [cart],
    );

  const resetKiosk =
    useCallback(() => {
      setStep('welcome');
      setServiceType(null);
      setCart([]);
      setSelectedProduct(null);
      setRecentlyAdded(null);
      setPaymentMethod(null);
      setPaymentStatus(
        'pending',
      );
      setQris(null);
      setCreatedOrder(null);
      setError(null);
      setIsSubmitting(false);
      setActiveCategoryId(null);
    }, []);

  const handleSelectService =
    (
      selected:
        ServiceType,
    ) => {
      setServiceType(
        selected,
      );
      setStep('catalog');
    };

  const handleProductClick =
    (
      product:
        KioskProduct,
    ) => {
      setSelectedProduct(
        product,
      );
    };

  const handleAddProduct =
    (
      item:
        KioskCartItem,
    ) => {
      setCart(
        (current) => [
          ...current,
          item,
        ],
      );

      setSelectedProduct(
        null,
      );

      setRecentlyAdded({
        lineId:
          item.lineId,
        productName:
          item.name,
      });

      window.setTimeout(
        () => {
          setRecentlyAdded(
            (current) =>
              current?.lineId ===
              item.lineId
                ? null
                : current,
          );
        },
        3000,
      );
    };

  const handleUndoRecentlyAdded =
    () => {
      if (!recentlyAdded) {
        return;
      }

      setCart(
        (current) =>
          current.filter(
            (item) =>
              item.lineId !==
              recentlyAdded.lineId,
          ),
      );

      setRecentlyAdded(null);
    };

  const buildOrderPayload =
    (
      method:
        PaymentMethod,
    ) => ({
      slug:
        mitraSlug,
      branchSlug:
        branchSlug ??
        null,
      branchId:
        store.branchId,
      paymentMethod:
        method,
      serviceType:
        serviceType,
      tableCode:
        serviceType ===
        'takeaway'
          ? 'walk-in'
          : null,
      customer: {
        userId:
          null,
        name:
          'Kiosk Customer',
        email:
          null,
        phone:
          null,
      },
      items:
        cart.map(
          (item) => ({
            menuItemId:
              item.productId,
            name:
              item.name,
            quantity:
              item.quantity,
            priceAtOrder:
              item.basePrice +
              item.addOns.reduce(
                (
                  total,
                  addOn,
                ) =>
                  total +
                  addOn.price,
                0,
              ),
            selectedAddOnsDetails:
              item.addOns,
            notes:
              item.notes ??
              null,
          }),
        ),
      discount:
        0,
      total:
        subtotal,
      totalAfterDiscount:
        subtotal,
    });

  const createOrder =
    async (
      method:
        PaymentMethod,
    ) => {
      if (
        cart.length ===
        0 ||
        !serviceType
      ) {
        setError(
          'Keranjang atau tipe layanan belum dipilih.',
        );
        return;
      }

      setPaymentMethod(
        method,
      );
      setIsSubmitting(true);
      setError(null);

      try {
        const idempotencyKey =
          crypto.randomUUID();

        const response =
          await fetch(
            '/api/mobile/v1/pos/orders',
            {
              method:
                'POST',
              credentials:
                'include',
              headers: {
                Accept:
                  'application/json',
                'Content-Type':
                  'application/json',
                'X-Idempotency-Key':
                  idempotencyKey,
              },
              body:
                JSON.stringify(
                  buildOrderPayload(
                    method,
                  ),
                ),
            },
          );

        const result =
          await response.json() as
            CreateOrderResponse;

        if (
          !response.ok ||
          !result.success ||
          !result.data
        ) {
          throw new Error(
            result.message ||
              'Gagal membuat pesanan.',
          );
        }

        setCreatedOrder({
          id:
            result.data.orderId,
          code:
            result.data.orderCode,
        });

        if (
          method ===
          'qris'
        ) {
          if (
            !result.data.qris
              ?.qrUrl
          ) {
            throw new Error(
              'URL QRIS tidak ditemukan pada response.',
            );
          }

          setQris(
            result.data.qris,
          );

          setPaymentStatus(
            normalizePaymentState(
              result.data
                .paymentStatusLabel,
            ),
          );

          setStep('qris');
          return;
        }

        setStep('success');
      } catch (submitError) {
        setError(
          submitError instanceof Error
            ? submitError.message
            : 'Gagal membuat pesanan.',
        );
      } finally {
        setIsSubmitting(false);
      }
    };

  const pollQrisStatus =
    useCallback(async () => {
      if (
        !createdOrder
      ) {
        return;
      }

      try {
        const response =
          await fetch(
            `/api/mobile/v1/pos/orders/${createdOrder.id}/qris/status`,
            {
              credentials:
                'include',
              cache:
                'no-store',
              headers: {
                Accept:
                  'application/json',
              },
            },
          );

        const result =
          await response.json() as
            StatusResponse;

        if (
          !response.ok ||
          !result.success
        ) {
          throw new Error(
            result.message ||
              'Gagal mengecek pembayaran.',
          );
        }

        const nextStatus =
          normalizePaymentState(
            result.data
              ?.paymentStatusLabel,
          );

        setPaymentStatus(
          nextStatus,
        );

        if (
          nextStatus ===
          'paid'
        ) {
          setStep('success');
        }
      } catch (pollError) {
        console.error(
          '[KIOSK_QRIS_POLL_ERROR]',
          pollError,
        );
      }
    }, [createdOrder]);

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-stone-950 text-white">
        <div className="text-center">
          <div className="mx-auto h-14 w-14 animate-spin rounded-full border-4 border-white/20 border-t-amber-300" />
          <p className="mt-5 text-sm font-bold uppercase tracking-[0.28em] text-stone-400">
            Memuat kiosk
          </p>
        </div>
      </div>
    );
  }

  if (error && step === 'welcome') {
    return (
      <div className="flex min-h-screen items-center justify-center bg-stone-100 p-8">
        <div className="w-full max-w-2xl rounded-[2rem] bg-white p-10 text-center shadow-xl">
          <h1 className="text-4xl font-black text-stone-950">
            Kiosk belum siap
          </h1>
          <p className="mt-4 text-lg text-red-600">
            {error}
          </p>
          <button
            type="button"
            onClick={() =>
              void loadBootstrap()
            }
            className="mt-8 min-h-16 w-full rounded-2xl bg-stone-950 text-xl font-black text-white"
          >
            Coba Lagi
          </button>
        </div>
      </div>
    );
  }

  return (
    <KioskIdleGuard
      disabled={
        step === 'qris'
      }
      onReset={resetKiosk}
    >
      {step === 'welcome' && (
        <KioskWelcome
          storeName={
            store.name
          }
          logoUrl={
            store.logoUrl
          }
          tagline={
            store.tagline ??
            undefined
          }
          onStart={() =>
            setStep(
              'service-type',
            )
          }
        />
      )}

      {step ===
        'service-type' && (
        <KioskServiceType
          onBack={() =>
            setStep(
              'welcome',
            )
          }
          onSelect={
            handleSelectService
          }
        />
      )}

      {step === 'catalog' && (
        <KioskCatalog
          categories={
            categories
          }
          products={
            filteredProducts
          }
          activeCategoryId={
            activeCategoryId
          }
          cartQuantity={
            cartQuantity
          }
          cartTotal={
            subtotal
          }
          onCategoryChange={
            setActiveCategoryId
          }
          onProductClick={
            handleProductClick
          }
          onBack={() =>
            setStep(
              'service-type',
            )
          }
          onOpenCart={() =>
            setStep(
              'payment',
            )
          }
        />
      )}

      {step === 'payment' && (
        <div className="relative">
          <KioskPaymentMethod
            grandTotal={
              subtotal
            }
            onBack={() =>
              setStep(
                'catalog',
              )
            }
            onSelect={
              createOrder
            }
          />

          {isSubmitting && (
            <div className="fixed inset-0 z-[150] flex items-center justify-center bg-stone-950/80 backdrop-blur-sm">
              <div className="rounded-[2rem] bg-white p-10 text-center">
                <div className="mx-auto h-14 w-14 animate-spin rounded-full border-4 border-stone-200 border-t-amber-400" />
                <p className="mt-5 text-lg font-black text-stone-900">
                  Membuat pesanan...
                </p>
              </div>
            </div>
          )}

          {error && (
            <div className="fixed bottom-8 left-1/2 z-[160] w-[calc(100%-4rem)] max-w-2xl -translate-x-1/2 rounded-2xl bg-red-600 px-6 py-4 text-center font-bold text-white shadow-xl">
              {error}
            </div>
          )}
        </div>
      )}

      {step === 'qris' && (
        <KioskQrisPayment
          qris={qris}
          grandTotal={
            subtotal
          }
          paymentStatus={
            paymentStatus
          }
          onCancel={
            resetKiosk
          }
          onRetry={() =>
            void createOrder(
              'qris',
            )
          }
          onPoll={
            pollQrisStatus
          }
        />
      )}

      {step === 'success' && (
        <KioskOrderSuccess
          orderCode={
            createdOrder
              ?.code ??
            '-'
          }
          paymentMethod={
            paymentMethod ??
            'cash'
          }
          onFinish={
            resetKiosk
          }
        />
      )}

      <KioskProductModal
        open={
          selectedProduct !==
          null
        }
        product={
          selectedProduct
        }
        onClose={() =>
          setSelectedProduct(
            null,
          )
        }
        onAdd={
          handleAddProduct
        }
      />

      {recentlyAdded && (
        <div className="fixed bottom-28 left-1/2 z-[140] flex w-[calc(100%-4rem)] max-w-2xl -translate-x-1/2 items-center justify-between gap-4 rounded-2xl bg-stone-950 px-5 py-4 text-white shadow-2xl">
          <div className="min-w-0">
            <p className="truncate font-black">
              {recentlyAdded.productName} ditambahkan
            </p>
            <p className="mt-1 text-xs text-stone-400">
              Item masuk ke keranjang.
            </p>
          </div>

          <button
            type="button"
            onClick={
              handleUndoRecentlyAdded
            }
            className="shrink-0 rounded-xl bg-white/10 px-4 py-3 text-sm font-bold"
          >
            Batalkan
          </button>
        </div>
      )}
    </KioskIdleGuard>
  );
}
