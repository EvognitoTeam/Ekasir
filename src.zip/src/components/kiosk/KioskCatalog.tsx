'use client';

import { ArrowLeft, ShoppingCart } from 'lucide-react';
import KioskCategoryBar from './KioskCategoryBar';
import KioskProductCard from './KioskProductCard';
import type { KioskCategory, KioskProduct } from './types';

type Props = {
  categories: KioskCategory[];
  products: KioskProduct[];
  activeCategoryId: number | string | null;
  cartQuantity: number;
  cartTotal: number;
  onCategoryChange: (id: number | string | null) => void;
  onProductClick: (product: KioskProduct) => void;
  onBack: () => void;
  onOpenCart: () => void;
};

export default function KioskCatalog(props: Props) {
  return (
    <section className="min-h-screen bg-stone-100 pb-36">
      <header className="sticky top-0 z-40 border-b border-stone-200 bg-white">
        <div className="flex items-center justify-between px-8 py-6">
          <button type="button" onClick={props.onBack} className="flex h-14 w-14 items-center justify-center rounded-2xl bg-stone-100"><ArrowLeft className="h-6 w-6" /></button>
          <div className="text-center">
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-amber-600">Pilih menu</p>
            <h1 className="mt-1 text-3xl font-black">Mau makan apa?</h1>
          </div>
          <div className="w-14" />
        </div>
        <KioskCategoryBar categories={props.categories} activeCategoryId={props.activeCategoryId} onChange={props.onCategoryChange} />
      </header>

      <div className="grid grid-cols-2 gap-6 p-8">
        {props.products.map((product) => (
          <KioskProductCard key={product.id} product={product} onClick={props.onProductClick} />
        ))}
      </div>

      <div className="fixed bottom-0 left-1/2 z-50 w-full max-w-[1080px] -translate-x-1/2 border-t border-stone-200 bg-white p-6">
        <button type="button" disabled={props.cartQuantity === 0} onClick={props.onOpenCart} className="flex min-h-20 w-full items-center justify-between rounded-[1.5rem] bg-stone-950 px-7 text-white disabled:bg-stone-300">
          <div className="flex items-center gap-4">
            <ShoppingCart className="h-7 w-7" />
            <span className="text-xl font-black">Keranjang ({props.cartQuantity})</span>
          </div>
          <span className="text-xl font-black text-amber-300">Rp{props.cartTotal.toLocaleString('id-ID')}</span>
        </button>
      </div>
    </section>
  );
}
