'use client';

import { motion } from 'framer-motion';
import { ArrowRight, ShoppingBag } from 'lucide-react';

type Props = {
  storeName: string;
  tagline?: string;
  logoUrl?: string | null;
  onStart: () => void;
};

export default function KioskWelcome({
  storeName,
  tagline = 'Pesan dengan cepat, mudah, dan nyaman.',
  logoUrl,
  onStart,
}: Props) {
  return (
    <section className="relative flex min-h-screen flex-col overflow-hidden bg-stone-950 px-10 py-12 text-white">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(251,191,36,0.28),transparent_34%),radial-gradient(circle_at_bottom_left,rgba(255,255,255,0.10),transparent_28%)]" />

      <div className="relative z-10 flex flex-1 flex-col">
        <div className="flex items-center justify-between">
          <div className="flex h-20 w-20 items-center justify-center overflow-hidden rounded-3xl border border-white/10 bg-white/10">
            {logoUrl ? (
              <img src={logoUrl} alt={storeName} className="h-full w-full object-cover" />
            ) : (
              <ShoppingBag className="h-10 w-10" />
            )}
          </div>
          <div className="rounded-full border border-white/10 bg-white/10 px-5 py-3 text-xs font-bold uppercase tracking-[0.25em] text-stone-300">
            Self Order Kiosk
          </div>
        </div>

        <div className="flex flex-1 flex-col justify-center py-16">
          <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="text-sm font-bold uppercase tracking-[0.35em] text-amber-300">
            Selamat datang
          </motion.p>
          <motion.h1 initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }} className="mt-6 max-w-4xl text-7xl font-black leading-[0.94] tracking-[-0.06em]">
            Pesan favoritmu di
            <span className="block text-amber-300">{storeName}</span>
          </motion.h1>
          <p className="mt-8 max-w-2xl text-2xl leading-relaxed text-stone-300">{tagline}</p>
        </div>

        <motion.button type="button" onClick={onStart} whileTap={{ scale: 0.98 }} className="flex min-h-24 w-full items-center justify-between rounded-[2rem] bg-amber-300 px-10 text-left text-stone-950 shadow-2xl shadow-amber-500/20">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.22em] text-stone-700">Mulai sekarang</p>
            <p className="mt-1 text-3xl font-black">Sentuh untuk memesan</p>
          </div>
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-stone-950 text-white">
            <ArrowRight className="h-8 w-8" />
          </div>
        </motion.button>
      </div>
    </section>
  );
}
