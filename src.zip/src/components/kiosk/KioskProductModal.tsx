'use client';

import {
  useEffect,
  useMemo,
  useState,
} from 'react';

import {
  Check,
  Minus,
  Plus,
  X,
} from 'lucide-react';

import type {
  KioskAddOn,
  KioskCartItem,
  KioskProduct,
} from './types';

type KioskProductModalProps = {
  open: boolean;
  product:
    | KioskProduct
    | null;
  onClose: () => void;
  onAdd: (
    item: KioskCartItem,
  ) => void;
};

export default function KioskProductModal({
  open,
  product,
  onClose,
  onAdd,
}: KioskProductModalProps) {
  const [
    quantity,
    setQuantity,
  ] = useState(1);

  const [
    selectedAddOns,
    setSelectedAddOns,
  ] =
    useState<KioskAddOn[]>(
      [],
    );

  const [
    notes,
    setNotes,
  ] = useState('');

  useEffect(() => {
    if (!open) {
      return;
    }

    const timer =
      window.setTimeout(
        () => {
          setQuantity(1);
          setSelectedAddOns([]);
          setNotes('');
        },
        0,
      );

    return () => {
      window.clearTimeout(
        timer,
      );
    };
  }, [
    open,
    product?.id,
  ]);

  const addOnTotal =
    useMemo(
      () =>
        selectedAddOns.reduce(
          (
            total,
            addOn,
          ) =>
            total +
            addOn.price,
          0,
        ),
      [selectedAddOns],
    );

  const unitPrice =
    (
      product?.price ??
      0
    ) +
    addOnTotal;

  const total =
    unitPrice *
    quantity;

  if (
    !open ||
    !product
  ) {
    return null;
  }

  const toggleAddOn =
    (
      addOn:
        KioskAddOn,
    ) => {
      setSelectedAddOns(
        (current) =>
          current.some(
            (item) =>
              item.id ===
              addOn.id,
          )
            ? current.filter(
                (item) =>
                  item.id !==
                  addOn.id,
              )
            : [
                ...current,
                addOn,
              ],
      );
    };

  const handleAdd =
    () => {
      onAdd({
        lineId: [
          String(
            product.id,
          ),
          Date.now(),
          Math.random()
            .toString(36)
            .slice(2, 8),
        ].join('-'),
        productId:
          product.id,
        name:
          product.name,
        imageUrl:
          product.imageUrl ||
          '/logo.png',
        quantity,
        basePrice:
          product.price,
        addOns:
          selectedAddOns,
        notes:
          notes.trim() ||
          undefined,
      });
    };

  return (
    <div
      className="fixed inset-0 z-[150] flex items-end justify-center bg-stone-950/70 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label={`Detail ${product.name}`}
    >
      <div className="max-h-[94dvh] w-full max-w-[1080px] overflow-y-auto rounded-t-[3rem] bg-white shadow-2xl">
        <header className="sticky top-0 z-20 flex items-center justify-between border-b border-stone-200 bg-white/95 px-8 py-6 backdrop-blur-xl">
          <div className="min-w-0">
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-amber-600">
              Pilih variasi
            </p>
            <h2 className="mt-1 truncate text-3xl font-black text-stone-950">
              {product.name}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-stone-100 text-stone-700"
          >
            <X className="h-6 w-6" />
          </button>
        </header>

        <div className="grid grid-cols-[340px_1fr] gap-8 p-8">
          <div>
            <div className="flex h-[340px] items-center justify-center overflow-hidden rounded-[2rem] bg-stone-50 p-8">
              <img
                src={
                  product.imageUrl ||
                  '/logo.png'
                }
                alt={product.name}
                className="h-full w-full object-contain"
                onError={(
                  event,
                ) => {
                  event.currentTarget.src =
                    '/logo.png';
                }}
              />
            </div>

            {product.description && (
              <p className="mt-5 text-base leading-relaxed text-stone-500">
                {product.description}
              </p>
            )}

            <div className="mt-5 rounded-2xl bg-stone-100 px-5 py-4">
              <p className="text-sm font-bold uppercase tracking-wider text-stone-400">
                Harga dasar
              </p>
              <p className="mt-1 text-2xl font-black text-stone-950">
                Rp
                {product.price.toLocaleString(
                  'id-ID',
                )}
              </p>
            </div>
          </div>

          <div className="space-y-7">
            <section>
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-black text-stone-950">
                  Add-on
                </h3>

                <span className="text-sm font-semibold text-stone-400">
                  Opsional
                </span>
              </div>

              {product.addOns &&
              product.addOns.length > 0 ? (
                <div className="mt-4 grid grid-cols-2 gap-3">
                  {product.addOns.map(
                    (addOn) => {
                      const selected =
                        selectedAddOns.some(
                          (item) =>
                            item.id ===
                            addOn.id,
                        );

                      return (
                        <button
                          key={addOn.id}
                          type="button"
                          onClick={() =>
                            toggleAddOn(
                              addOn,
                            )
                          }
                          className={`flex min-h-20 items-center justify-between gap-4 rounded-2xl border px-5 text-left transition ${
                            selected
                              ? 'border-amber-400 bg-amber-50'
                              : 'border-stone-200 bg-white'
                          }`}
                        >
                          <div className="min-w-0">
                            <p className="truncate font-black text-stone-900">
                              {addOn.name}
                            </p>
                            <p className="mt-1 text-sm font-bold text-amber-700">
                              + Rp
                              {addOn.price.toLocaleString(
                                'id-ID',
                              )}
                            </p>
                          </div>

                          <span
                            className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
                              selected
                                ? 'bg-amber-400 text-stone-950'
                                : 'bg-stone-100 text-stone-400'
                            }`}
                          >
                            {selected ? (
                              <Check className="h-5 w-5" />
                            ) : (
                              <Plus className="h-5 w-5" />
                            )}
                          </span>
                        </button>
                      );
                    },
                  )}
                </div>
              ) : (
                <div className="mt-4 rounded-2xl border border-dashed border-stone-300 bg-stone-50 px-5 py-6 text-center text-sm font-medium text-stone-400">
                  Produk ini tidak memiliki add-on.
                </div>
              )}
            </section>

            <section>
              <label
                htmlFor="kiosk-product-notes"
                className="text-sm font-bold uppercase tracking-wider text-stone-500"
              >
                Catatan pesanan
              </label>

              <textarea
                id="kiosk-product-notes"
                value={notes}
                onChange={(
                  event,
                ) =>
                  setNotes(
                    event.target.value,
                  )
                }
                placeholder="Contoh: tidak pedas, tanpa bawang"
                className="mt-3 min-h-28 w-full resize-none rounded-2xl border border-stone-200 bg-stone-50 p-4 text-lg outline-none transition focus:border-amber-400"
              />
            </section>

            <section className="flex items-center justify-between rounded-2xl bg-stone-100 p-4">
              <div>
                <p className="text-sm font-bold uppercase tracking-wider text-stone-400">
                  Jumlah
                </p>
                <p className="mt-1 text-lg font-black text-stone-800">
                  {quantity} item
                </p>
              </div>

              <div className="flex items-center gap-5">
                <button
                  type="button"
                  onClick={() =>
                    setQuantity(
                      (value) =>
                        Math.max(
                          1,
                          value - 1,
                        ),
                    )
                  }
                  className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-stone-950 shadow-sm"
                >
                  <Minus className="h-6 w-6" />
                </button>

                <span className="min-w-10 text-center text-3xl font-black">
                  {quantity}
                </span>

                <button
                  type="button"
                  onClick={() =>
                    setQuantity(
                      (value) =>
                        value + 1,
                    )
                  }
                  className="flex h-14 w-14 items-center justify-center rounded-2xl bg-stone-950 text-white"
                >
                  <Plus className="h-6 w-6" />
                </button>
              </div>
            </section>

            <button
              type="button"
              onClick={handleAdd}
              className="flex min-h-20 w-full items-center justify-between rounded-[1.5rem] bg-amber-300 px-7 text-stone-950 shadow-lg shadow-amber-200/50"
            >
              <span className="text-xl font-black">
                Tambahkan ke keranjang
              </span>

              <span className="text-xl font-black">
                Rp
                {total.toLocaleString(
                  'id-ID',
                )}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
