'use client';

import { ArrowLeft, Banknote, QrCode } from 'lucide-react';
import type { KioskPaymentMethod as Method } from './types';

type Props = {
  grandTotal: number;
  onBack: () => void;
  onSelect: (method: Method) => void;
};

export default function KioskPaymentMethod({ grandTotal, onBack, onSelect }: Props) {
  return (
    <section className="min-h-screen bg-stone-100 px-8 py-10">
      <button type="button" onClick={onBack} className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white shadow-sm"><ArrowLeft className="h-6 w-6" /></button>

      <div className="mx-auto mt-16 max-w-3xl text-center">
        <p className="text-sm font-bold uppercase tracking-[0.3em] text-amber-600">Pembayaran</p>
        <h1 className="mt-5 text-6xl font-black tracking-[-0.05em]">Pilih metode bayar</h1>
        <div className="mx-auto mt-8 w-fit rounded-2xl bg-white px-8 py-5 shadow-sm">
          <p className="text-sm font-bold uppercase tracking-widest text-stone-400">Total pembayaran</p>
          <p className="mt-2 text-4xl font-black">Rp{grandTotal.toLocaleString('id-ID')}</p>
        </div>
      </div>

      <div className="mx-auto mt-14 grid max-w-4xl grid-cols-2 gap-8">
        <button type="button" onClick={() => onSelect('qris')} className="flex min-h-[390px] flex-col items-center justify-center rounded-[2.5rem] border border-stone-200 bg-white p-10 text-center shadow-xl">
          <div className="flex h-28 w-28 items-center justify-center rounded-[2rem] bg-stone-950 text-white"><QrCode className="h-14 w-14" /></div>
          <h2 className="mt-8 text-4xl font-black">QRIS</h2>
          <p className="mt-4 text-lg text-stone-500">Bayar dengan aplikasi bank atau e-wallet.</p>
        </button>

        <button type="button" onClick={() => onSelect('cash')} className="flex min-h-[390px] flex-col items-center justify-center rounded-[2.5rem] border border-stone-200 bg-white p-10 text-center shadow-xl">
          <div className="flex h-28 w-28 items-center justify-center rounded-[2rem] bg-stone-950 text-white"><Banknote className="h-14 w-14" /></div>
          <h2 className="mt-8 text-4xl font-black">Bayar di Kasir</h2>
          <p className="mt-4 text-lg text-stone-500">Selesaikan pembayaran tunai di kasir.</p>
        </button>
      </div>
    </section>
  );
}
