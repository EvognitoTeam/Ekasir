import { NextResponse } from 'next/server';

export const dynamic =
  'force-dynamic';

export const runtime =
  'nodejs';

type UnknownRecord =
  Record<string, unknown>;

type ProductApiResponse = {
  success?: boolean;
  message?: string;
  data?: unknown;
  categoriesData?: unknown;
  mitraName?: unknown;
  mitraAddress?: unknown;
  mitraWelcome?: unknown;
  branchName?: unknown;
  logoUrl?: unknown;
  mitraLogo?: unknown;
  mitraId?: unknown;
  branchId?: unknown;
};

type KioskCategory = {
  id: number | string;
  name: string;
  slug?: string;
};

type KioskAddOn = {
  id: number | string;
  name: string;
  price: number;
};

type KioskProduct = {
  id: number | string;
  name: string;
  description: string | null;
  price: number;
  imageUrl: string | null;
  categoryId:
    | number
    | string
    | null;
  categoryName:
    | string
    | null;
  isAvailable: boolean;
  stock: number | null;
  addOns: KioskAddOn[];
};

function jsonError(
  status: number,
  message: string,
  code =
    'KIOSK_BOOTSTRAP_FAILED',
  details: unknown = null,
) {
  return NextResponse.json(
    {
      success: false,
      message,
      error: {
        code,
        details,
      },
    },
    {
      status,
    },
  );
}

function asRecord(
  value: unknown,
): UnknownRecord {
  if (
    value &&
    typeof value ===
      'object' &&
    !Array.isArray(value)
  ) {
    return value as
      UnknownRecord;
  }

  return {};
}

function normalizeString(
  value: unknown,
): string {
  return String(
    value ?? '',
  ).trim();
}

function normalizeNullableString(
  value: unknown,
): string | null {
  const normalized =
    normalizeString(value);

  return normalized ||
    null;
}

function normalizeNumber(
  value: unknown,
  fallback = 0,
): number {
  const parsed =
    Number(value);

  return Number.isFinite(
    parsed,
  )
    ? parsed
    : fallback;
}


function decodeHtmlEntities(
  value: string,
): string {
  const entities:
    Record<string, string> = {
      '&nbsp;': ' ',
      '&amp;': '&',
      '&quot;': '"',
      '&#39;': "'",
      '&apos;': "'",
      '&lt;': '<',
      '&gt;': '>',
    };

  return value.replace(
    /&nbsp;|&amp;|&quot;|&#39;|&apos;|&lt;|&gt;/gi,
    (entity) =>
      entities[
        entity.toLowerCase()
      ] ?? entity,
  );
}

function stripHtml(
  value: unknown,
): string | null {
  const raw =
    normalizeNullableString(
      value,
    );

  if (!raw) {
    return null;
  }

  const withoutTags =
    raw
      .replace(
        /<br\s*\/?>/gi,
        ' ',
      )
      .replace(
        /<\/p>/gi,
        ' ',
      )
      .replace(
        /<[^>]*>/g,
        ' ',
      );

  const decoded =
    decodeHtmlEntities(
      withoutTags,
    )
      .replace(
        /\s+/g,
        ' ',
      )
      .trim();

  return decoded || null;
}

function parseMoneyValue(
  value: unknown,
): number | null {
  if (
    typeof value ===
      'number' &&
    Number.isFinite(value)
  ) {
    return value;
  }

  if (
    typeof value ===
      'string'
  ) {
    const raw =
      value.trim();

    if (!raw) {
      return null;
    }

    /*
     * Mendukung:
     * 15000
     * 15.000
     * Rp15.000
     * 15,000.00
     * 15000.00
     */
    const cleaned =
      raw
        .replace(
          /rp/gi,
          '',
        )
        .replace(
          /\s+/g,
          '',
        )
        .replace(
          /[^0-9,.-]/g,
          '',
        );

    if (!cleaned) {
      return null;
    }

    let normalized =
      cleaned;

    const hasComma =
      normalized.includes(',');

    const hasDot =
      normalized.includes('.');

    if (
      hasComma &&
      hasDot
    ) {
      const lastComma =
        normalized.lastIndexOf(',');

      const lastDot =
        normalized.lastIndexOf('.');

      if (
        lastDot >
        lastComma
      ) {
        normalized =
          normalized.replace(
            /,/g,
            '',
          );
      } else {
        normalized =
          normalized
            .replace(
              /\./g,
              '',
            )
            .replace(
              ',',
              '.',
            );
      }
    } else if (
      hasDot
    ) {
      const dotParts =
        normalized.split('.');

      const looksIndonesianThousands =
        dotParts.length > 1 &&
        dotParts
          .slice(1)
          .every(
            (part) =>
              part.length === 3,
          );

      if (
        looksIndonesianThousands
      ) {
        normalized =
          normalized.replace(
            /\./g,
            '',
          );
      }
    } else if (
      hasComma
    ) {
      const commaParts =
        normalized.split(',');

      const looksThousands =
        commaParts.length > 1 &&
        commaParts
          .slice(1)
          .every(
            (part) =>
              part.length === 3,
          );

      normalized =
        looksThousands
          ? normalized.replace(
              /,/g,
              '',
            )
          : normalized.replace(
              ',',
              '.',
            );
    }

    const parsed =
      Number(normalized);

    return Number.isFinite(
      parsed,
    )
      ? parsed
      : null;
  }

  if (
    value &&
    typeof value ===
      'object' &&
    !Array.isArray(value)
  ) {
    const record =
      value as UnknownRecord;

    const nested =
      pickFirst(
        record,
        [
          'value',
          'amount',
          'price',
          'basePrice',
          'base_price',
          'sellingPrice',
          'selling_price',
          'finalPrice',
          'final_price',
          'minPrice',
          'min_price',
        ],
      );

    if (
      nested !==
      undefined
    ) {
      return parseMoneyValue(
        nested,
      );
    }
  }

  return null;
}

function resolveProductPrice(
  product: UnknownRecord,
): number {
  const directCandidates =
    [
      'price',
      'selling_price',
      'sellingPrice',
      'base_price',
      'basePrice',
      'product_price',
      'productPrice',
      'final_price',
      'finalPrice',
      'display_price',
      'displayPrice',
      'min_price',
      'minPrice',
      'harga',
    ];

  for (
    const key of
    directCandidates
  ) {
    const parsed =
      parseMoneyValue(
        product[key],
      );

    if (
      parsed !== null
    ) {
      return Math.max(
        0,
        Math.round(parsed),
      );
    }
  }

  const arrayCandidates =
    [
      product.variants,
      product.skus,
      product.options,
      product.productVariants,
      product.product_variants,
    ];

  for (
    const candidate of
    arrayCandidates
  ) {
    if (
      !Array.isArray(
        candidate,
      )
    ) {
      continue;
    }

    const prices =
      candidate
        .map(
          (item) =>
            parseMoneyValue(
              item,
            ),
        )
        .filter(
          (
            price,
          ): price is number =>
            price !== null &&
            price >= 0,
        );

    if (
      prices.length > 0
    ) {
      return Math.round(
        Math.min(
          ...prices,
        ),
      );
    }
  }

  return 0;
}

function normalizeNullableNumber(
  value: unknown,
): number | null {
  if (
    value === null ||
    value === undefined ||
    value === ''
  ) {
    return null;
  }

  const parsed =
    Number(value);

  return Number.isFinite(
    parsed,
  )
    ? parsed
    : null;
}

function normalizeBoolean(
  value: unknown,
  fallback = true,
): boolean {
  if (
    value === null ||
    value === undefined ||
    value === ''
  ) {
    return fallback;
  }

  if (
    typeof value ===
    'boolean'
  ) {
    return value;
  }

  if (
    typeof value ===
    'number'
  ) {
    return value === 1;
  }

  const normalized =
    normalizeString(value)
      .toLowerCase();

  if (
    [
      '1',
      'true',
      'yes',
      'active',
      'available',
    ].includes(
      normalized,
    )
  ) {
    return true;
  }

  if (
    [
      '0',
      'false',
      'no',
      'inactive',
      'unavailable',
      'sold_out',
    ].includes(
      normalized,
    )
  ) {
    return false;
  }

  return fallback;
}

function normalizeId(
  value: unknown,
  fallback: number,
): number | string {
  if (
    typeof value ===
      'number' &&
    Number.isFinite(value)
  ) {
    return value;
  }

  const normalized =
    normalizeString(value);

  return normalized ||
    fallback;
}

function pickFirst(
  record: UnknownRecord,
  keys: string[],
): unknown {
  for (
    const key of keys
  ) {
    if (
      record[key] !==
        undefined &&
      record[key] !==
        null
    ) {
      return record[key];
    }
  }

  return undefined;
}

const DEFAULT_IMAGE_URL =
  '/logo.png';

function normalizeImageUrl(
  value: unknown,
): string {
  const image =
    normalizeNullableString(
      value,
    );

  if (!image) {
    return DEFAULT_IMAGE_URL;
  }

  if (
    image.startsWith(
      'http://',
    ) ||
    image.startsWith(
      'https://',
    ) ||
    image.startsWith(
      'data:',
    ) ||
    image.startsWith(
      'blob:',
    ) ||
    image.startsWith(
      '/',
    )
  ) {
    return image;
  }

  return `/${image.replace(
    /^\/+/,
    '',
  )}`;
}

function normalizeAddOns(
  value: unknown,
): KioskAddOn[] {
  if (
    !Array.isArray(value)
  ) {
    return [];
  }

  return value
    .map(
      (
        rawAddOn,
        index,
      ) => {
        const addOn =
          asRecord(
            rawAddOn,
          );

        const name =
          normalizeString(
            pickFirst(
              addOn,
              [
                'name',
                'title',
                'label',
                'addon_name',
                'add_on_name',
              ],
            ),
          );

        if (!name) {
          return null;
        }

        return {
          id:
            normalizeId(
              pickFirst(
                addOn,
                [
                  'id',
                  'addon_id',
                  'add_on_id',
                ],
              ),
              index + 1,
            ),
          name,
          price:
            Math.max(
              0,
              normalizeNumber(
                pickFirst(
                  addOn,
                  [
                    'price',
                    'additionalPrice',
                    'additional_price',
                    'addon_price',
                  ],
                ),
                0,
              ),
            ),
        };
      },
    )
    .filter(
      (
        addOn,
      ): addOn is
        KioskAddOn =>
        addOn !== null,
    );
}

function normalizeCategory(
  rawCategory: unknown,
  index: number,
): KioskCategory | null {
  const category =
    asRecord(
      rawCategory,
    );

  const name =
    normalizeString(
      pickFirst(
        category,
        [
          'name',
          'category_name',
          'title',
        ],
      ),
    );

  if (!name) {
    return null;
  }

  const slug =
    normalizeNullableString(
      pickFirst(
        category,
        [
          'slug',
          'category_slug',
        ],
      ),
    );

  return {
    id:
      normalizeId(
        pickFirst(
          category,
          [
            'id',
            'category_id',
          ],
        ),
        index + 1,
      ),
    name,
    ...(slug
      ? {
          slug,
        }
      : {}),
  };
}

function normalizeProduct(
  rawProduct: unknown,
  index: number,
): KioskProduct | null {
  const product =
    asRecord(
      rawProduct,
    );

  const name =
    normalizeString(
      pickFirst(
        product,
        [
          'name',
          'product_name',
          'title',
        ],
      ),
    );

  if (!name) {
    return null;
  }

  const price =
    resolveProductPrice(
      product,
    );

  const category =
    asRecord(
      pickFirst(
        product,
        [
          'category',
          'categoryData',
        ],
      ),
    );

  const categoryIdValue =
    pickFirst(
      product,
      [
        'categoryId',
        'category_id',
      ],
    ) ??
    pickFirst(
      category,
      [
        'id',
        'category_id',
      ],
    );

  const categoryName =
    normalizeNullableString(
      pickFirst(
        product,
        [
          'categoryName',
          'category_name',
        ],
      ) ??
      pickFirst(
        category,
        [
          'name',
          'category_name',
        ],
      ),
    );

  const stock =
    normalizeNullableNumber(
      pickFirst(
        product,
        [
          'stock',
          'quantity',
          'remainingStock',
          'remaining_stock',
        ],
      ),
    );

  const explicitlyAvailable =
    pickFirst(
      product,
      [
        'isAvailable',
        'is_available',
        'available',
        'isActive',
        'is_active',
        'status',
      ],
    );

  const isAvailable =
    normalizeBoolean(
      explicitlyAvailable,
      true,
    ) &&
    (
      stock === null ||
      stock > 0
    );

  return {
    id:
      normalizeId(
        pickFirst(
          product,
          [
            'id',
            'product_id',
            'menuItemId',
          ],
        ),
        index + 1,
      ),
    name,
    description:
      stripHtml(
        pickFirst(
          product,
          [
            'description',
            'product_description',
            'desc',
          ],
        ),
      ),
    price,
    imageUrl:
      normalizeImageUrl(
        pickFirst(
          product,
          [
            'imageUrl',
            'image_url',
            'image',
            'photo',
            'thumbnail',
          ],
        ),
      ),
    categoryId:
      categoryIdValue ===
        null ||
      categoryIdValue ===
        undefined ||
      categoryIdValue ===
        ''
        ? null
        : normalizeId(
            categoryIdValue,
            index + 1,
          ),
    categoryName,
    isAvailable,
    stock,
    addOns:
      normalizeAddOns(
        pickFirst(
          product,
          [
            'addOns',
            'addons',
            'add_ons',
            'options',
          ],
        ),
      ),
  };
}

export async function GET(
  request: Request,
): Promise<Response> {
  const requestUrl =
    new URL(
      request.url,
    );

  const slug =
    normalizeString(
      requestUrl.searchParams.get(
        'slug',
      ),
    );

  const branchSlug =
    normalizeNullableString(
      requestUrl.searchParams.get(
        'branch_slug',
      ),
    );

  if (!slug) {
    return jsonError(
      400,
      'Slug mitra wajib diisi.',
      'SLUG_REQUIRED',
    );
  }

  try {
    const productUrl =
      new URL(
        '/api/products',
        requestUrl.origin,
      );

    productUrl.searchParams.set(
      'slug',
      slug,
    );

    if (branchSlug) {
      productUrl.searchParams.set(
        'branch_slug',
        branchSlug,
      );
    }

    const productResponse =
      await fetch(
        productUrl,
        {
          method:
            'GET',
          headers: {
            Accept:
              'application/json',
            Cookie:
              request.headers.get(
                'cookie',
              ) ??
              '',
          },
          cache:
            'no-store',
        },
      );

    let productResult:
      ProductApiResponse;

    try {
      productResult =
        await productResponse.json() as
          ProductApiResponse;
    } catch {
      return jsonError(
        502,
        'API produk mengembalikan response yang tidak valid.',
        'INVALID_PRODUCT_API_RESPONSE',
      );
    }

    if (
      !productResponse.ok ||
      !productResult.success
    ) {
      return jsonError(
        productResponse.status >=
          400
          ? productResponse.status
          : 502,
        productResult.message ||
          'Mitra atau cabang tidak ditemukan.',
        'PRODUCT_API_FAILED',
      );
    }

    const rawCategories =
      Array.isArray(
        productResult.categoriesData,
      )
        ? productResult.categoriesData
        : [];

    const rawProducts =
      Array.isArray(
        productResult.data,
      )
        ? productResult.data
        : [];

    const categories =
      rawCategories
        .map(
          normalizeCategory,
        )
        .filter(
          (
            category,
          ): category is
            KioskCategory =>
            category !== null,
        );

    const products =
      rawProducts
        .map(
          normalizeProduct,
        )
        .filter(
          (
            product,
          ): product is
            KioskProduct =>
            product !== null,
        );

    const mitraId =
      normalizeNumber(
        productResult.mitraId,
        0,
      );

    const branchIdValue =
      productResult.branchId;

    const branchId =
      branchIdValue ===
        null ||
      branchIdValue ===
        undefined ||
      branchIdValue ===
        ''
        ? null
        : normalizeNumber(
            branchIdValue,
            0,
          ) ||
          null;

    const mitraName =
      normalizeString(
        productResult.mitraName,
      ) ||
      'EKASIR';

    const branchName =
      normalizeNullableString(
        productResult.branchName,
      );

    const displayName =
      branchName
        ? `${mitraName} - ${branchName}`
        : mitraName;

    return NextResponse.json(
      {
        success: true,
        message:
          'Data kiosk berhasil dimuat.',
        data: {
          store: {
            name:
              displayName,
            mitraName,
            branchName,
            logoUrl:
              normalizeImageUrl(
                productResult.logoUrl ??
                  productResult.mitraLogo,
              ),
            tagline:
              normalizeNullableString(
                productResult.mitraWelcome,
              ),
            address:
              normalizeNullableString(
                productResult.mitraAddress,
              ),
            mitraId,
            branchId,
            mitraSlug:
              slug,
            branchSlug,
          },
          categories,
          products,
          summary: {
            categoryCount:
              categories.length,
            productCount:
              products.length,
            availableProductCount:
              products.filter(
                (product) =>
                  product.isAvailable,
              ).length,
          },
        },
      },
      {
        status:
          200,
        headers: {
          'Cache-Control':
            'no-store, no-cache, must-revalidate',
        },
      },
    );
  } catch (error) {
    console.error(
      '[KIOSK_BOOTSTRAP_ERROR]',
      error,
    );

    return jsonError(
      500,
      'Gagal memuat data kiosk.',
      'KIOSK_BOOTSTRAP_INTERNAL_ERROR',
      process.env.NODE_ENV ===
        'development'
        ? {
            message:
              error instanceof Error
                ? error.message
                : String(error),
          }
        : null,
    );
  }
}